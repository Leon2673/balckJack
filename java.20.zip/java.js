let msgEl = document.getElementById("message-el")
let sumEl = document.getElementById("sum-el")
let cardEl = document.getElementById("card-el")
let card1 = randomcard()
let card2 = randomcard()
let cards = [card1 , card2]
let sum = card1 + card2
let bj = false 
let isAlive = true 
let message = ""
let player = {
    pername: 'per',
    perchip: 150
}
let playerEl = document.getElementById('per-el')
playerEl.innerText = player.pername + ': $' + player.perchip

function randomcard(){
  let rn = Math.floor(Math.random() * 13) + 1
  if ( rn > 10){
    return 10
  }
  else if(rn === 1){
    return 11
  }
  else {
    return rn
  }
}
function stgame(){
  rendergame()
}
function rendergame(){
  sumEl.innerText = "sum: " + sum
  cardEl.innerText = "card: " 
  for (i = 0; i < cards.length; i++){
    cardEl.innerText += cards[i] + "," 
    
  }
  if (sum < 21){
 message = "do you want to draw a card?"
  }  else if(sum > 21){
    message = "you have losed"
    isAlive = false 
  } else{
  message = "you have got blackjack"
  bj = true 
  }
  msgEl.innerText = message
}

function newcard(){
  if(isAlive === true && bj === false){
  let card = randomcard()
  sum += card
  cards.push(card)
  console.log(cards)
  rendergame()}
}
